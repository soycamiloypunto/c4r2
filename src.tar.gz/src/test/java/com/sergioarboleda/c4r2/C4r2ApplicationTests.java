package com.sergioarboleda.c4r2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C4r2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
