package com.sergioarboleda.c4r2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C4r2Application {

	public static void main(String[] args) {
		SpringApplication.run(C4r2Application.class, args);
	}

}
